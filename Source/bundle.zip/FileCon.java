package com.filecon;

import java.io.*;
import java.util.*;
import java.lang.*;
import java.nio.*;
import java.net.*;
import java.text.*;

import java.lang.annotation.ElementType;
import java.util.Map.Entry;
import static java.nio.file.StandardWatchEventKinds.*;
import java.nio.file.*;
import java.util.zip.*;




public final class FileCon {

	public static class FileSearch {
		public static class Argument{
			public String name;
			public int index;
			public int total;
			public Argument(String a, Integer b, Integer c){
				this.name = a;
				this.index = b;
				this.total = c;
			}
		};
		public static ArrayList<String> searchByName(String path, String query){
			FileSearchG g = new FileSearchG();
			var results = g.searchFiles(path, (Argument args) -> {
				return new TextMatcher(args.name).match(query) > 0;
			});
			return results;
		}
		public static ArrayList<String> searchByContent(String path, String query){
			FileSearchG g = new FileSearchG();
			var results = g.searchFiles(path, (Argument args) -> {
				return new TextMatcher(FileUtilG.readFile(args.name)).match(query) > 0;
			});
			return results;
		}
		public static ArrayList<String> search(String path, Callback<Argument, Boolean> cb){
			FileSearchG g = new FileSearchG();
			var results = g.searchFiles(path, cb);
			return results;
		}
	}

	public static class FileWatcher {

		public static class FileEvent extends EventObject{
			protected String kind = "none";
			public FileEvent(WatchEvent.Kind<?> kind, File file){
				super(file);
				String k = "none";
				if(kind == ENTRY_CREATE) k = "create";
				if(kind == ENTRY_MODIFY) k = "modify";
				if(kind == ENTRY_DELETE) k = "delete";
				this.kind = k;
			}
			public File getFile(){
				return (File) getSource();
			}
			public String getKind(){
				return kind;
			}
		}

		public FileWatcher(String folder, CallbackWithOne<FileEvent> fn) throws IOException, InterruptedException {
			WatchService watchService = FileSystems.getDefault().newWatchService();
			Path path = Paths.get(folder);
			path.register(watchService, ENTRY_CREATE, ENTRY_MODIFY, ENTRY_DELETE);
			boolean poll = true;
			while(poll){
				WatchKey key = watchService.take();
				for(WatchEvent<?> event : key.pollEvents()){
					FileEvent fevent = new FileEvent(event.kind(), path.resolve((Path) event.context()).toFile());
					fn.call(fevent);
				}
				poll = key.reset();
			}
		}
	}
	public static class FileUtilExtra extends FileUtilGExtra {}
	public static class FileUtil extends FileUtilG {}
	public static final class FileCompression {

		protected static void compressFile(String filePath, String to) throws FileNotFoundException, IOException {

			File file = new File(filePath);
			String zipFileName = to;

			FileOutputStream fos = new FileOutputStream(zipFileName);
			ZipOutputStream zos = new ZipOutputStream(fos);

			zos.putNextEntry(new ZipEntry(file.getName()));

			byte[] bytes = Files.readAllBytes(Paths.get(filePath));
			zos.write(bytes, 0, bytes.length);
			zos.closeEntry();
			zos.close();

		}

		protected static void compressFiles(String[] filePaths, String zipFilePath) throws FileNotFoundException, IOException {

			FileOutputStream fos = new FileOutputStream(zipFilePath);
			ZipOutputStream zos = new ZipOutputStream(fos);
				
			for(String filePath : filePaths){
				zos.putNextEntry(new ZipEntry(new File(filePath).getName()));
				byte[] bytes = Files.readAllBytes(Paths.get(filePath));
				zos.write(bytes, 0, bytes.length);
				zos.closeEntry();
			}

			zos.close();
		}

		// protected static String compressFolder(String folderPath, String zipFilePath){

		// }

		public static void zipFile(String filePath, String zipFilePath) throws FileNotFoundException, IOException {
			compressFile(filePath, zipFilePath);
		}

		public static void zipFiles(String zipFilePath, String ...filePaths) throws FileNotFoundException, IOException {
			compressFiles(filePaths, zipFilePath);
		}
		public static void zipFiles(String[] filePaths, String zipFilePath) throws FileNotFoundException, IOException {
			compressFiles(filePaths, zipFilePath);
		}

		public static void zipFolder(String folderPath, String zipFilePath) throws FileNotFoundException, IOException {
			File file = new File(folderPath);
			String[] files = file.list();

			zipFiles(files, zipFilePath);

			// compressFolder(folderPath, zipFilePath);
		}

	}

	public static void main(String[] args) throws IOException, InterruptedException {
		FileCompression.zipFolder("../bundle","../bundle.zip");
	}

}

@FunctionalInterface
interface Callback<P, R> {
	public R call(P param);
}

@FunctionalInterface
interface CallbackWithOne<P> {
	public void call(P param);
}

@interface FNFile {
	ElementType [] values();
}

public interface Writer {
	FCPath path();
	String data();
}

class FileSearchG {

	public String ext(String file){
		String exte = file;
		if(file.indexOf(".") > -1){
			exte = file.substring(file.lastIndexOf(".") + 1);
		}
		return exte;
	}

	public ArrayList<String> searchFiles(String path, Callback<FileCon.FileSearch.Argument, Boolean> fn){
		ArrayList<String> searched = new ArrayList<String>();
		int index = 0;
		int totalFiles = 0;
		int foundFiles = 0;
		File file = new File(path);
		listFileAndSearch(file.listFiles(), index, searched, totalFiles, foundFiles, fn);
		return searched;
	}

	private void listFileAndSearch(File [] nodes, int index, ArrayList<String> searched, int totalFiles, int foundFiles, Callback<FileCon.FileSearch.Argument, Boolean> fn){
		if(index > nodes.length)
			return;

		for(File child : nodes){
			if(child.isFile()){
				if(fn.call(new FileCon.FileSearch.Argument(child.getAbsolutePath(), index, nodes.length))){
					searched.add(child.getAbsolutePath());
					foundFiles++;
				}
			}
			if(child.isDirectory()){
				// open recursively
				listFileAndSearch(Objects.requireNonNull(child.listFiles()), Objects.requireNonNull(child.listFiles()).length, searched, totalFiles, foundFiles, fn);
			}
		}

		totalFiles++;
		index += 1;
	}
}

class At {

	private static String[] a_z = "abcdefghijklmnopqrtuvwxyz".split("");
	
	public static String pickRandom(String ...args){
		var words = args;
		var randomWord = words;
		var rand = randFrom(0,randomWord.length-1);
		return randomWord[rand];
	}

	public static int randFrom(int min, int max) {
		return (int) Math.floor(Math.random()*(max-min+1)+min);
	};

	public static String rand(){
		var rnd = new String();
		for (var i = 0; i < 24; i++) {
		var r = pickRandom(
			String.valueOf(randFrom(0,9)),
			String.valueOf(randFrom(i,randFrom(i*2,i*4))),
			a_z[randFrom(0,a_z.length-1)]
		);
		rnd += r;
		}
		return rnd;
	}
	
}

class FileUtilG {

		private static void createNewFile(String str) {
				int lastIndexOf = str.lastIndexOf(File.separator);
				if (lastIndexOf > 0) {
						makeDir(str.substring(0, lastIndexOf));
				}
				File file = new File(str);
				try {
						if (!file.exists()) {
								file.createNewFile();
						}
				} catch (IOException e) {
						e.printStackTrace();
				}
		}

		public static String readFile(String str) {
				FileReader fileReader;
				IOException e;
				IOException e2;
				Throwable th;
				createNewFile(str);
				StringBuilder stringBuilder = new StringBuilder();
				try {
						fileReader = new FileReader(new File(str));
						try {
								char[] cArr = new char[1024];
								while (true) {
										int read = fileReader.read(cArr);
										if (read <= 0) {
												break;
										}
										stringBuilder.append(new String(cArr, 0, read));
								}
								if (fileReader != null) {
										try {
												fileReader.close();
										} catch (Exception e2_) {
												e2_.printStackTrace();
										}
								}
						} catch (IOException e3) {
								e = e3;
						}
				} catch (IOException e4) {
						e = e4;
						fileReader = null;
						try {
								e.printStackTrace();
								if (fileReader != null) {
										try {
												fileReader.close();
										} catch (Exception e22) {
												e22.printStackTrace();
										}
								}
								return stringBuilder.toString();
						} catch (Throwable th2) {
								th = th2;
								if (fileReader != null) {
										try {
												fileReader.close();
										} catch (Exception e5) {
												e5.printStackTrace();
										}
								}
								
						}
				} catch (Throwable th3) {
						th = th3;
						fileReader = null;
						if (fileReader != null) {
								try {
										fileReader.close();
								} catch (Exception e5) {
										e5.printStackTrace();
								}
						}
						
				}
				return stringBuilder.toString();
		}

		public static void writeFile(String str, String str2) {
				FileWriter fileWriter;
				IOException e;
				IOException e2;
				IOException e22;
				Throwable th;
				createNewFile(str);
				FileWriter fileWriter2 = null;
				try {
						fileWriter = new FileWriter(new File(str), false);
						try {
								fileWriter.write(str2);
								fileWriter.flush();
								if (fileWriter != null) {
										try {
												fileWriter.close();
										} catch (IOException e2_) {
												e2_.printStackTrace();
										}
								}
						} catch (IOException e3) {
								e2 = e3;
								try {
										e2.printStackTrace();
										if (fileWriter != null) {
												try {
														fileWriter.close();
												} catch (IOException e22_) {
														e22_.printStackTrace();
												}
										}
								} catch (Throwable th2) {
										th = th2;
										fileWriter2 = fileWriter;
										if (fileWriter2 != null) {
												try {
														fileWriter2.close();
												} catch (IOException e4) {
														e4.printStackTrace();
												}
										}
										
								}
						}
				} catch (IOException e5) {
						e22 = e5;
						fileWriter = null;
						e22.printStackTrace();
						if (fileWriter != null) {
								try {
										fileWriter.close();
								} catch (Exception _ee5) {
										_ee5.printStackTrace();
								}
						}
				} catch (Throwable th3) {
						th = th3;
						if (fileWriter2 != null) {
								try {
										fileWriter2.close();
								} catch (Exception e5) {
										e5.printStackTrace();
								}
						}
						
				}
		}

		public static void copyFile(String str, String str2) {
				FileInputStream fileInputStream;
				FileOutputStream fileOutputStream;
				IOException e;
				IOException e22;
				IOException e2222;
				Throwable th;
				FileInputStream fileInputStream2 = null;
				if (isExistFile(str)) {
						createNewFile(str2);
						try {
								fileInputStream = new FileInputStream(str);
								try {
										fileOutputStream = new FileOutputStream(str2, false);
										try {
												byte[] bArr = new byte[1024];
												while (true) {
														int read = fileInputStream.read(bArr);
														if (read <= 0) {
																break;
														}
														fileOutputStream.write(bArr, 0, read);
												}
												if (fileInputStream != null) {
														try {
																fileInputStream.close();
														} catch (IOException e2) {
																e2.printStackTrace();
														}
												}
												if (fileOutputStream != null) {
														try {
																fileOutputStream.close();
														} catch (IOException e22_) {
																e22_.printStackTrace();
														}
												}
										} catch (IOException e3) {
												e22 = e3;
												fileInputStream2 = fileInputStream;
										} catch (Throwable th2) {
												th = th2;
										}
								} catch (IOException e4) {
										e22 = e4;
										fileOutputStream = null;
										fileInputStream2 = fileInputStream;
										try {
												e22.printStackTrace();
												if (fileInputStream2 != null) {
														try {
																fileInputStream2.close();
														} catch (IOException e222) {
																e222.printStackTrace();
														}
												}
												if (fileOutputStream != null) {
														try {
																fileOutputStream.close();
														} catch (IOException e2222_) {
																e2222_.printStackTrace();
														}
												}
										} catch (Throwable th3) {
												th = th3;
												fileInputStream = fileInputStream2;
												if (fileInputStream != null) {
														try {
																fileInputStream.close();
														} catch (IOException e5) {
																e5.printStackTrace();
														}
												}
												if (fileOutputStream != null) {
														try {
																fileOutputStream.close();
														} catch (IOException e6) {
																e6.printStackTrace();
														}
												}
												
										}
								} catch (Throwable th4) {
										th = th4;
										fileOutputStream = null;
										if (fileInputStream != null) {
												fileInputStream.close();
										}
										if (fileOutputStream != null) {
												fileOutputStream.close();
										}
										
								}
						} catch (IOException e7) {
								e2222 = e7;
								fileOutputStream = null;
								e2222.printStackTrace();
								if (fileInputStream2 != null) {
										try {
												fileInputStream2.close();
										} catch (Exception _ee5) {
												_ee5.printStackTrace();
										}
								}
								if (fileOutputStream != null) {
										try {
												fileOutputStream.close();
										} catch (Exception _ee5) {
												_ee5.printStackTrace();
										}
								}
						} catch (Throwable th5) {
								th = th5;
								fileOutputStream = null;
								fileInputStream = null;
								if (fileInputStream != null) {
										try {
												fileInputStream.close();
										} catch (Exception _ee5) {
												_ee5.printStackTrace();
										}
								}
								if (fileOutputStream != null) {
										try {
												fileOutputStream.close();
										} catch (Exception _ee5) {
												_ee5.printStackTrace();
										}
								}
								
						}
				}
		}

		public static void moveFile(String str, String str2) {
				copyFile(str, str2);
				deleteFile(str);
		}

		public static void deleteFile(String str) {
				File file = new File(str);
				if (!file.exists()) {
						return;
				}
				if (file.isFile()) {
						file.delete();
						return;
				}
				File[] listFiles = file.listFiles();
				if (listFiles != null) {
						for (File file2 : listFiles) {
								if (file2.isDirectory()) {
										deleteFile(file2.getAbsolutePath());
								}
								if (file2.isFile()) {
										file2.delete();
								}
						}
				}
				file.delete();
		}

		public static boolean isExistFile(String str) {
				return new File(str).exists();
		}

		public static void makeDir(String str) {
				if (!isExistFile(str)) {
						new File(str).mkdirs();
				}
		}

		public static void listDir(String str, ArrayList<String> arrayList) {
				File file = new File(str);
				if (file.exists() && !file.isFile()) {
						File[] listFiles = file.listFiles();
						if (listFiles != null && listFiles.length > 0 && arrayList != null) {
								arrayList.clear();
								for (File absolutePath : listFiles) {
										arrayList.add(absolutePath.getAbsolutePath());
								}
						}
				}
		}

		public static boolean isDirectory(String str) {
				if (isExistFile(str)) {
						return new File(str).isDirectory();
				}
				return false;
		}

		public static boolean isFile(String str) {
				if (isExistFile(str)) {
						return new File(str).isFile();
				}
				return false;
		}

		public static long getFileLength(String str) {
				if (isExistFile(str)) {
						return new File(str).length();
				}
				return 0;
		}
}

class PathUtil {

	public static String ext(String file){
		String exte = file;
		if(file.indexOf(".") > -1){
			exte = file.substring(file.lastIndexOf(".") + 1);
		}
		return exte;
	}

	public static String lastPath(String file){
		String exte = file;
		if(file.indexOf("/") > -1){
			exte = file.substring(file.lastIndexOf("/") + 1);
		}
		if(file.indexOf("\\") > -1){
			exte = file.substring(file.lastIndexOf("\\") + 1);
		}
		return exte;
	}

	public static String trimLastPath(String file){
		String exte = file;
		if(file.indexOf("/") > -1){
			exte = file.substring(0, file.lastIndexOf("/") + 1);
		}
		if(file.indexOf("\\") > -1){
			exte = file.substring(0, file.lastIndexOf("\\") + 1);
		}
		return exte;
	}

	public Boolean isExt(String file, String req){
		return ext(file).equals(req);
	}

	public Boolean isImageExt(String file){
		return isExt(file, "png") || isExt(file, "jpg") ||
		isExt(file, "img") || isExt(file, "jpeg") ||
		isExt(file, "ico") || isExt(file, "gif");
	}

	public Boolean isTextExt(String file){
		return isExt(file, "txt") || isExt(file, "c") ||
		isExt(file, "cs") || isExt(file, "h") ||
		isExt(file, "java") || isExt(file, "json") ||
		isExt(file, "js") || isExt(file, "py") ||
		isExt(file, "ini") || isExt(file, "html") ||
		isExt(file, "css") || isExt(file, "htm") ||
		isExt(file, "php") || isExt(file, "jsx") ||
		isExt(file, "ts") || isExt(file, "ejs") ||
		isExt(file, "md") || isExt(file, "cmd") ||
		isExt(file, "ps") || isExt(file, "sh") ||
		isExt(file, "bat") || isExt(file, "r");
	}

	public static void main(String[] args) {
		PathUtil path = new PathUtil();
	}

}

class DirInfo {

	/*
	 * Base algorithm to list files recursively
	 */
	private static long totalSize = 0L;
	private static int totalFiles = 0;

	private static void openFiles(File[] files, int index) {
		if (index > files.length)
			return;

		for (File f : files) {
			if (f.isFile()) {
				totalSize += f.length();
				totalFiles++;
			}

			if (f.isDirectory())
				openFiles(Objects.requireNonNull(f.listFiles()), index);
		}
		index += 1;
	}


	/*
	 * by opening files recursively calculates each file size
	 * based on FileCon recursive algorithm
	 */
	public static long totalSizeOfFiles(FCPath path) {
		if (path.isEmpty() || !path.isPath())
			return 0L;

		if (FileUtilGExtra.isFile(path))
			return 0L;

		openFiles(Objects.requireNonNull(FileUtilGExtra.allFiles(path)), 0);
		return totalSize;
	}

	public static float sizeInKB(FCPath path) {
		return FileSize.toKB(totalSizeOfFiles(path));
	}

	public static float sizeInMB(FCPath path) {
		return FileSize.toMB(totalSizeOfFiles(path));
	}

	public static float sizeInGB(FCPath path) {
		return FileSize.toGB(totalSizeOfFiles(path));
	}

	public static int totalFiles(FCPath path) {
		if (path.isEmpty() || !path.isPath())
			return 0;

		openFiles(Objects.requireNonNull(FileUtilGExtra.allFiles(path)), 0);
		return totalFiles;
	}

	public static int totalDirs(FCPath path) {
		return (Objects.requireNonNull(FileUtilGExtra.allFiles(path)).length) - totalFiles(path);
	}

}

class FileClassifier {

	private static final HashMap<TYPE, String []> fileMap;
	private static final String [] IMAGE_FORMATS = {"jpg", "png", "png"};
	private static final String [] AUDIO_FORMAT ={"mp3","m4a", "ogg"};
	private static final String [] VIDEO_FORMAT ={"mp4", "avi","mkv"};
	private static final String [] OTHER_FORMAT ={"pdf", "txt", "js", "java"};

	static{
		fileMap = new HashMap<>();
		fileMap.put(TYPE.IMAGE, IMAGE_FORMATS);
		fileMap.put(TYPE.AUDIO, AUDIO_FORMAT);
		fileMap.put(TYPE.VIDEO, VIDEO_FORMAT);
		fileMap.put(TYPE.OTHER, OTHER_FORMAT);
	}

	public static TYPE getType(FCPath path){
		TYPE fileTYPE = TYPE.FILE;
		String format = FileUtilGExtra.getFormat(path);
		for (Entry entry: fileMap.entrySet()){
			for(String formats : (String[]) entry.getValue()){
				if (formats.equals(format)) {
					fileTYPE = (TYPE) entry.getKey();
					break;
				}
			}
		}
		return fileTYPE;
	}

	public static enum TYPE{
		IMAGE,
		AUDIO,
		VIDEO,
		OTHER,
		FILE
	}
}

class FileInfo {

	private static SimpleDateFormat dateFormat;

	public static String basicInfo(FCPath path){
		if(path.isEmpty() || !path.isPath())
			return null;

		dateFormat = new SimpleDateFormat("dd/MM/yyyy - hh:mm:ss");
		return (String) dateFormat.format(Objects.requireNonNull(FileUtilGExtra.fromPath(path)).lastModified());
	}

	public static String formattedInfo(String format, FCPath path){
		if(path.isEmpty() || !path.isPath())
			return null;

		dateFormat = new SimpleDateFormat(format);
		return (String) dateFormat.format(Objects.requireNonNull(FileUtilGExtra.fromPath(path)).lastModified());
	}

	public static float sizeInKB(FCPath path){
		long bytes = Objects.requireNonNull(FileUtilGExtra.fromPath(path)).length();
		return FileSize.toKB(bytes);
	}

	public static float sizeInMB(FCPath path){
		long bytes = Objects.requireNonNull(FileUtilGExtra.fromPath(path)).length();
		return FileSize.toMB(bytes);
	}

	public static float sizeInGB(FCPath path){
		long bytes = Objects.requireNonNull(FileUtilGExtra.fromPath(path)).length();
		return FileSize.toGB(bytes);
	}

	private static long sizeInByte(FCPath path){
		return Objects.requireNonNull(FileUtilGExtra.fromPath(path)).length();
	}
}

class FileSize {

	private static final float SIZE = 1024f;

	/*
	 * based on long b converts a given byte to KB
	 */
	public static float toKB(long b){ return b/SIZE; }

	/*
	 * converts a given byte to MB
	 */
	public static float toMB(long b){ return ((b/SIZE)/SIZE); }

	/*
	 * converts a given byte to GB
	 */
	public static float toGB(long b){ return (((b/SIZE)/SIZE)/SIZE); }

}

public class FileUtilGExtra {

	/*
	 * static method
	 * returns true if file is created successfully or false
	 */
	public static boolean createFile(FCPath path) {
		if(path.isEmpty() || !path.isPath())
			throw new NullPointerException();

		File mFile = fromPath(path);
		try {
			assert mFile != null;
			return mFile.createNewFile();
		} catch (IOException e) {
			throw new NullPointerException(e.toString());
		}
	}

	/*
	 * creates multiple files from a given Path
	 */
	public static void createFiles(FCPath[] path) {
		for (FCPath p : path) {
			if(p.isPath() && !p.isEmpty()){
				File mFile = new File(p.getPath());
				if(!mFile.exists()){
					try {
						mFile.createNewFile();
					} catch (IOException e) {
						throw new NullPointerException(e.toString());
					}
				}
			}
		}
	}

	/*
	 * creates a single dir
	 */
	public static boolean createDir(FCPath path) {
		if (path.isPath() && !path.isEmpty()) {
			File mFile = new File(path.getPath());
			if (!mFile.exists())
				return mFile.mkdir();
			else
				return false;
		}

		throw new NullPointerException();
	}

	/*
	 * creates multiple dirs
	 */
	public static void createDirs(FCPath[] paths) {
		for (FCPath p : paths) {
			if (p.isPath() && !p.isEmpty()) {
				File mFile = new File(p.getPath());
				if (mFile.exists())
					return;
				mFile.mkdir();
			}
		}
	}


	/*
	 * deletes a given file or folder
	 */
	public static boolean delete(FCPath path) {
		if(path.isPath() && !path.isEmpty()){
			return Objects.requireNonNull(fromPath(path)).delete();
		}

		throw new NullPointerException();
	}

	// deletes multiple files  from a given path
	public static void deleteFiles(FCPath[] paths) {
		for (FCPath p : paths) {
			if (p.isPath() && !p.isEmpty()){
				File dFiles = new File(p.getPath());
				if (!dFiles.exists())
					throw new NullPointerException();
				dFiles.delete();
			}
		}
	}

	// rename a file from a given path
	public static boolean rename(FCPath source, FCPath dest) {

		if(source.isPath() && !source.isEmpty() &&  dest.isPath() && !dest.isEmpty()){
			File src = new File(source.getPath());
			File dst = new File(dest.getPath());
			if(!src.exists())
				throw new NullPointerException();

			return src.renameTo(dst);
		}

		throw new NullPointerException();
	}

	// rename multiple files with path array
	// but a little bit slow uses O(n)
	public static void renameFiles(FCPath[] src, FCPath[] dst) {
		if (src.length != dst.length)
			return;

		for (int i = 0; i < src.length; i++) {
			if (src[i].isEmpty() || !src[i].isPath())
				return;

			if (dst[i].isEmpty() || !dst[i].isPath())
				return;

			File source = new File(src[i].getPath());
			File dest = new File(src[i].getPath());
			if (source.exists()) {
				source.renameTo(dest);
			}

		}
	}


	/*
	 * checks a file or dir exists or not exist
	 */
	public static boolean exist(FCPath path) {
		if(path.isPath() && !path.isEmpty())
			return fromPath(path).exists();

		return false;
	}

	/*
	 * checks if a a given
	 */
	public static boolean isFile(FCPath path) {
		if (!path.isPath() || path.isEmpty())
			return false;

		return fromPath(path).isFile();
	}


	/*
	 * checks if a given path is a Directory
	 */
	public static boolean isDirectory(FCPath path) {
		if (!path.isPath() || path.isEmpty())
			return false;

		return fromPath(path).isDirectory();
	}


	/*
	 * public method uof file format
	 */
	public static String getFormat(FCPath path){
		if(!path.isPath() || path.isEmpty())
			return null;

		String fileName = Objects.requireNonNull(fromPath(path)).getName();
		return format(fileName);
	}


	/*
	 * returns a file format.... .mp3, mp4, jpg
	 */
	private static String format(String s){
		if(!s.contains("."))
			return null;

		StringBuilder f = new StringBuilder();
		for(int i =s.length()-1; i>=0; i--){
			if(s.toCharArray()[i]=='.')
				break;
			f.append(s.toCharArray()[i]);
		}

		return f.reverse().toString();
	}


	/*
	 * returns File object from a given path
	 */
	public static File fromPath(FCPath p) {
		return new File(p.getPath());
	}


	/*
	 * returns a FIle [] of both files and dirs
	 */
	public static File [] allFiles(FCPath path){
		if (!path.isPath() || path.isEmpty())
			return null;

		if(isFile(path) || exist(path))
			return null;

		return (File[]) Objects.requireNonNull(fromPath(path)).listFiles();
	}

	/*
	 * returns a FIle [] of only files from a given path
	 */
	public static File [] files(FCPath path){
		if (!path.isPath() || path.isEmpty())
			return null;

		if(FileUtilGExtra.isFile(path))
			return null;

		File [] mFiles = new File[DirInfo.totalFiles(path)];
		int index  = 0;
		for(File file: Objects.requireNonNull(allFiles(path))){
			if(file.isDirectory())
				continue;

			mFiles[index]=new File(file.getPath());
			index++;
		}
		return mFiles;
	}

	/*
	 * returns a FIle [] of only dirs from a given path
	 */
	public static File [] dirs(FCPath path){
		if (!path.isPath() || path.isEmpty())
			return null;

		if(FileUtilGExtra.isFile(path))
			return null;

		File [] mFiles = new File[DirInfo.totalDirs(path)];
		int index  = 0;
		for(File file: Objects.requireNonNull(allFiles(path))){
			if(file.isFile())
				continue;

			mFiles[index]=new File(file.getPath());
			index++;
		}
		return mFiles;
	}

}

class FCPath {

	private String path; // base path

	/*
	 * uses factory method to construct in order to use methods efficiently
	 */
	@FNFile(values = ElementType.CONSTRUCTOR)
	public FCPath(String path){
		this.path = path;
	}

	/*
	 * factory method class initialization
	 */
	public static FCPath form(String path){
		return new FCPath(path);
	}

	/*
	 * returns direct path
	 */
	@FNFile(values = {ElementType.METHOD})
	public String getPath() {
		return path;
	}
	/*
	 * appends a path
	 */
	public void append(String p){
		if(path.endsWith("/"))
			path += p;

		path += "/"+p;
	}
	/*
	 * checks if path is empty or null
	 */
	public boolean isEmpty(){return path==null || path.equals("");}

	/*
	 * it is based on operating systems to check if a path has the '/' char
	 * on windows path usually starts with letters
	 * on linux based OS including android path starts with '/'
	 */
	public boolean isPath(){  return path.startsWith("/") || path.contains("/"); }

	/*
	 * returns path at a given index
	 * as isEmpty() method this one is also based on OS
	 */
	public String getPathAt(int index){
		String p = null;
		String [] subPath = null;
		if(path.startsWith("/"))
			path = path.substring(1, path.length());

		subPath = path.split("/");
		if(index >= subPath.length)
			return null;

		for(int i = 0; i<subPath.length; i++){
			if(i == index) {
				p = subPath[i];
				return p;
			}
		}

		return null;
	}

	@Override
	public String toString() {
		return "Path{" +
				"path='" + path + '\'' +
				'}';
	}

}

class FileConFileReader {

	/*
	 * This is a file reader object
	 * reads as many formats
	 */
	public static String readRaw(FCPath p) {
		if (!FileUtilGExtra.exist(p) || FileUtilGExtra.isDirectory(p))
			return null;

		StringBuilder mBuilder = new StringBuilder();
		BufferedReader bufferedReader = null;
		try {
			bufferedReader = new BufferedReader(new FileReader(FileUtilGExtra.fromPath(p)));
			String data = "";
			while ((data = bufferedReader.readLine()) != null) {
				mBuilder.append(data);
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				assert bufferedReader != null;
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return mBuilder.toString();
	}

	public static String read(FCPath p) {

		if (!FileUtilGExtra.exist(p) || FileUtilGExtra.isDirectory(p))
			return null;

		StringBuilder mBuilder = new StringBuilder();
		BufferedReader bufferedReader = null;
		try {
			bufferedReader = new BufferedReader(new FileReader(FileUtilGExtra.fromPath(p)));
			String data = "";
			while ((data = bufferedReader.readLine()) != null) {
				mBuilder.append(data);
				mBuilder.append((char) 10);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				assert bufferedReader != null;
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return mBuilder.toString();
	}

	public static List<String> readByLine(FCPath p) {
		if (!FileUtilGExtra.exist(p) || FileUtilGExtra.isDirectory(p))
			return null;

		List<String> lines = new ArrayList<>();
		try {
			Scanner fScanner = new Scanner(FileUtilGExtra.fromPath(p));
			while (fScanner.hasNext()) {
				lines.add(fScanner.nextLine());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		return lines;
	}

	public static String readLine(FCPath path, int start){
		if (!FileUtilGExtra.exist(path) || FileUtilGExtra.isDirectory(path))
			return null;

		if(start >= Objects.requireNonNull(readByLine(path)).size())
			return null;

		StringBuilder stringBuilder = new StringBuilder();
		List<String> lines = readByLine(path);
		for(int i = start; i< Objects.requireNonNull(lines).size(); i++){
			stringBuilder.append(lines.get(i));
		}
		return stringBuilder.toString();
	}

	public static String readLine(FCPath path, int start, int end){
		if (!FileUtilGExtra.exist(path) || FileUtilGExtra.isDirectory(path))
			return null;

		if(start >= Objects.requireNonNull(readByLine(path)).size() || end >= Objects.requireNonNull(readByLine(path)).size())
			return null;

		if(start==end)
			return null;

		StringBuilder stringBuilder = new StringBuilder();
		List<String> lines = readByLine(path);
		for(int i = start; i< end; i++){
			assert lines != null;
			stringBuilder.append(lines.get(i));
		}
		return stringBuilder.toString();
	}

}

class FileConFileWriter {

	public static void write(Writer w){

		if(FileUtilGExtra.exist(w.path()))
			return;

		if(!FileUtilGExtra.isFile(w.path()))
			return;

		BufferedWriter bufferedWriter = null;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(FileUtilGExtra.fromPath(w.path())));
			bufferedWriter.write(w.data());
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			assert bufferedWriter != null;
			try {
				bufferedWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}

class TextFilter {

	private final String data; // base data

	public TextFilter(String data) {
		this.data = data;
	}

	public String getData() {
		return data;
	}

	public int length() {
		return data.length();
	}

	/*
	 * returns the amount of char in data
	 * m = size of data
	 * uses O(m) for searching
	 */
	public int amountOf(char a) {
		int amount = 0;
		for (char c : data.toCharArray()) {
			if (c == a)
				amount++;
		}

		return amount;
	}

	/*
	 * checks amount of c in data
	 * base algorithm to search
	 */
	public int amountOf(String c){
		if(c == null || c.equals(""))
			return 0;

		if(c.equals(data))
			return 1;

		int s = 0;
		for(int i = 0; i <= data.length() - c.length(); i++){
			String window = data.substring(i, i + c.length());
			if(c.equals(window)){
				s += 1;
				i += (c.length()-1);
			}
		}

		return s;
	}

	/*
	public int amountOf(String c) {
		if(c==null || c.equals(""))
			return 0;

		int q = data.length() - (data.length() % c.length());
		q = (q % 2 == 1) ? q : q + 1;
		int FileCon = 0;
		for (int i = 0; i < q - c.length(); i++) {
			String window = data.substring(i, i + c.length());
			if (c.equals(window)) {
				FileCon++;
			}
		}
		return FileCon;
	}
	 */
	public float getPercent(char c) {
		return ((float) amountOf(c) / (float) data.length()) * 100f;
	}

	public float getPercent(String c) { return (((float) amountOf(c) * c.length()) / (float) length() ) * 100f; }

	@Override
	public String toString() {
		return "TextFilter{" +
				"data='" + data + '\'' +
				'}';
	}

}

class TextMatcher {

	private final String data;

	public TextMatcher(String data){
		this.data = data;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		TextMatcher that = (TextMatcher) o;
		return Objects.equals(data, that.data);
	}

	@Override
	public int hashCode() {
		return 0;
	}

	public float match(String search){
		if(equals((Object)search))
			return 100f;

		return new TextFilter(data).getPercent(search);

	}

}








